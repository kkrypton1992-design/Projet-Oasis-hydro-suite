/**
 * OASIS HYDRO SUITE — Client API Frontend
 * Interface avec le backend Express & PostgreSQL avec fallback automatique
 */

import { Project, Watershed, HydraulicStructure, ProjectSettings } from '../types/oasis.ts';
import { getStoredProject, saveProject as saveLocalProject } from './storageService.ts';

const API_BASE = '/api';

export class ApiClient {
  /**
   * Récupère le projet actif depuis la base de données PostgreSQL
   */
  static async getActiveProject(): Promise<Project> {
    try {
      const res = await fetch(`${API_BASE}/projects/active`, {
        headers: { 'Accept': 'application/json' }
      });
      if (res.ok) {
        const data = await res.json();
        // Mettre en cache local pour mode déconnecté
        saveLocalProject(data);
        return data;
      }
    } catch (err) {
      console.warn('API non joignable (mode hors-ligne ou fallback local):', err);
    }
    return getStoredProject();
  }

  /**
   * Sauvegarde le projet complet dans PostgreSQL via l'API REST
   */
  static async saveProject(project: Project): Promise<Project> {
    // 1. Sauvegarde locale immédiate
    saveLocalProject(project);

    // 2. Persistance dans PostgreSQL
    try {
      const res = await fetch(`${API_BASE}/projects/${project.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(project)
      });
      if (res.ok) {
        const saved = await res.json();
        saveLocalProject(saved);
        return saved;
      }
    } catch (err) {
      console.warn('Erreur sauvegarde API (sauvegarde locale conservée):', err);
    }
    return project;
  }

  /**
   * Met à jour un ouvrage hydraulique spécifique en base
   */
  static async updateStructure(projectId: string, structure: HydraulicStructure): Promise<Project> {
    try {
      const res = await fetch(`${API_BASE}/projects/${projectId}/structures/${structure.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(structure)
      });
      if (res.ok) {
        const updatedProject = await res.json();
        saveLocalProject(updatedProject);
        return updatedProject;
      }
    } catch (err) {
      console.warn('Erreur updateStructure API:', err);
    }
    // Fallback local
    const current = getStoredProject();
    const updatedStructures = current.structures.map(s => s.id === structure.id ? structure : s);
    const updated = { ...current, structures: updatedStructures };
    saveLocalProject(updated);
    return updated;
  }

  /**
   * Met à jour les réglages normatifs en base
   */
  static async updateSettings(projectId: string, settings: ProjectSettings): Promise<Project> {
    try {
      const res = await fetch(`${API_BASE}/projects/${projectId}/settings`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        const updatedProject = await res.json();
        saveLocalProject(updatedProject);
        return updatedProject;
      }
    } catch (err) {
      console.warn('Erreur updateSettings API:', err);
    }
    // Fallback local
    const current = getStoredProject();
    const updated = { ...current, settings };
    saveLocalProject(updated);
    return updated;
  }
}
