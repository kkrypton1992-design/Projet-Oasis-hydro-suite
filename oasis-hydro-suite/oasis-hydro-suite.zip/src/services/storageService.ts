/**
 * OASIS HYDRO SUITE — Service de Stockage Persistant & Gestion des Projets
 * Compatible 100% Web (LocalStorage, Import/Export JSON) et 100% Desktop (Electron/Système de fichiers)
 */

import { calculateHydraulicBehavior } from '../core/hydraulicEngine';
import { calculateRationalFlows, calculateTimeOfConcentration } from '../core/hydrologyEngine';
import { Project } from '../types/oasis';

const STORAGE_KEY = 'oasis_hydro_suite_active_project';
const PROJECTS_LIST_KEY = 'oasis_hydro_suite_projects_index';

// Données réelles de référence basées sur un aménagement routier et de drainage
export const DEFAULT_REAL_PROJECT: Project = {
  id: 'prj-rn1-pk25-real',
  code: 'PRJ-2026-HYD-01',
  title: 'Voie Express Régionale — Étude Hydraulique et Dimensionnement des Ouvrages de Franchissement (PK 0+000 à PK 25+000)',
  client: 'Direction Régionale des Infrastructures et des Transports (DRIT)',
  engineer: 'Département Ouvrages d\'Art & Hydraulique Fluviale',
  location: 'Corridor d\'infrastructure Vallée Ouest',
  description: 'Projet d\'exécution pour le rétablissement des écoulements naturels, le dimensionnement des buses, dalots cadres et fossés longitudinaux pour les crues de récurrence décennale (Q10), cinquantennale (Q50) et centennale (Q100).',
  createdAt: '2026-03-15T08:30:00.000Z',
  updatedAt: new Date().toISOString(),
  status: 'IN_PROGRESS',
  version: '1.2.0',
  settings: {
    region: 'Zone Hydro-Climatique Tempérée / Océanique B2',
    departmentOrCountry: 'France / Bassin Adour-Garonne',
    returnPeriodDesignYears: 25,
    returnPeriodCheckYears: 100,
    minSelfCleaningVelocity: 0.60,
    maxVelocityConcrete: 4.00,
    maxVelocityEarth: 1.50,
    maxFillingRatio: 0.80,
    minFreeboardM: 0.25,
    montanaParams: [
      { periodReturnYears: 10, a: 5.65, b: 0.62 },
      { periodReturnYears: 25, a: 7.10, b: 0.61 },
      { periodReturnYears: 50, a: 8.45, b: 0.60 },
      { periodReturnYears: 100, a: 10.15, b: 0.59 }
    ]
  },
  watersheds: [
    {
      id: 'bv-01',
      code: 'BV-01',
      name: 'Bassin Versant du Ruisseau des Combes (PK 3+250)',
      areaKm2: 0.85,
      lengthKm: 1.45,
      deltaH: 42,
      slopePercent: 2.9,
      runoffCoefficient: 0.55,
      soilType: 'Argilo-silteux avec zones boisées',
      vegetation: 'Bocage et prairies permanentes',
      color: '#0284c7',
      coordinates: [
        { lat: 43.615, lng: 1.412 },
        { lat: 43.622, lng: 1.428 },
        { lat: 43.626, lng: 1.440 },
        { lat: 43.618, lng: 1.448 },
        { lat: 43.608, lng: 1.439 },
        { lat: 43.604, lng: 1.422 },
        { lat: 43.615, lng: 1.412 }
      ]
    },
    {
      id: 'bv-02',
      code: 'BV-02',
      name: 'Bassin Versant du Ravin de Saint-Pierre (PK 8+700)',
      areaKm2: 3.20,
      lengthKm: 3.10,
      deltaH: 95,
      slopePercent: 3.1,
      runoffCoefficient: 0.62,
      soilType: 'Marno-calcaire et talus rocheux',
      vegetation: 'Zones agricoles mixtes et garrigue',
      color: '#0d9488',
      coordinates: [
        { lat: 43.628, lng: 1.455 },
        { lat: 43.642, lng: 1.472 },
        { lat: 43.645, lng: 1.498 },
        { lat: 43.633, lng: 1.512 },
        { lat: 43.619, lng: 1.492 },
        { lat: 43.617, lng: 1.468 },
        { lat: 43.628, lng: 1.455 }
      ]
    },
    {
      id: 'bv-03',
      code: 'BV-03',
      name: 'Bassin Versant Majeur du Val d\'Ombre (PK 14+120)',
      areaKm2: 8.60,
      lengthKm: 5.80,
      deltaH: 180,
      slopePercent: 3.1,
      runoffCoefficient: 0.68,
      soilType: 'Schistes métamorphiques et colluvions',
      vegetation: 'Versants boisés denses et habitat diffus en amont',
      color: '#7c3aed',
      coordinates: [
        { lat: 43.646, lng: 1.518 },
        { lat: 43.668, lng: 1.535 },
        { lat: 43.678, lng: 1.572 },
        { lat: 43.662, lng: 1.605 },
        { lat: 43.638, lng: 1.585 },
        { lat: 43.631, lng: 1.542 },
        { lat: 43.646, lng: 1.518 }
      ]
    }
  ],
  structures: [
    {
      id: 'oh-01',
      code: 'OH-01',
      pkMeters: 3250,
      name: 'Ouvrage sous chaussée PK 3+250 (Buse circulaire)',
      type: 'CIRCULAR_PIPE',
      material: 'CONCRETE',
      stricklerK: 70,
      diameterM: 1.20,
      cellsCount: 1,
      lengthM: 22.5,
      bedSlopeMPerM: 0.012, // 1.2%
      watershedId: 'bv-01',
      designFlowM3s: 2.15, // Q25
      checkFlowM3s: 2.85,  // Q100
      position: { lat: 43.612, lng: 1.428 }
    },
    {
      id: 'oh-02',
      code: 'OH-02',
      pkMeters: 8700,
      name: 'Franchissement Ravin PK 8+700 (Dalot cadre 2.50x1.50m)',
      type: 'BOX_CULVERT',
      material: 'CONCRETE',
      stricklerK: 70,
      widthM: 2.50,
      heightM: 1.50,
      cellsCount: 1,
      lengthM: 28.0,
      bedSlopeMPerM: 0.008, // 0.8%
      watershedId: 'bv-02',
      designFlowM3s: 7.42, // Q25
      checkFlowM3s: 9.85,  // Q100
      position: { lat: 43.626, lng: 1.478 }
    },
    {
      id: 'oh-03',
      code: 'OH-03',
      pkMeters: 14120,
      name: 'Franchissement majeur Val d\'Ombre PK 14+120 (Dalot double 2x 3.00x2.00m)',
      type: 'BOX_CULVERT',
      material: 'CONCRETE',
      stricklerK: 70,
      widthM: 3.00,
      heightM: 2.00,
      cellsCount: 2,
      lengthM: 34.0,
      bedSlopeMPerM: 0.006, // 0.6%
      watershedId: 'bv-03',
      designFlowM3s: 18.90, // Q25
      checkFlowM3s: 24.80, // Q100
      position: { lat: 43.642, lng: 1.548 }
    },
    {
      id: 'oh-04',
      code: 'OH-04',
      pkMeters: 18350,
      name: 'Fossé trapézoïdal latéral de décharge PK 18+350',
      type: 'DITCH',
      material: 'EARTH_GRASSED',
      stricklerK: 35,
      widthM: 0.80, // largeur fond b
      heightM: 1.20,
      sideSlopeM: 1.5, // 1V:1.5H
      cellsCount: 1,
      lengthM: 450.0,
      bedSlopeMPerM: 0.005, // 0.5%
      watershedId: 'bv-01',
      designFlowM3s: 0.95,
      checkFlowM3s: 1.30,
      position: { lat: 43.655, lng: 1.582 }
    }
  ]
};

/**
 * Calcul et synchronisation des résultats réels pour tous les BV et ouvrages du projet
 */
export function recalculateEntireProject(project: Project): Project {
  // 1. Recalcul hydrologique sur chaque BV
  const updatedWatersheds = project.watersheds.map(ws => {
    const tcComp = calculateTimeOfConcentration(ws.areaKm2, ws.lengthKm, ws.deltaH);
    const chosenMethod = ws.calculatedTc?.chosenMethod || tcComp.recommendedMethod;
    const chosenValue = chosenMethod === 'KIRPICH' ? tcComp.kirpichMin
      : chosenMethod === 'PASSINI' ? tcComp.passiniMin
      : chosenMethod === 'GIANDOTTI' ? tcComp.giandottiMin
      : tcComp.bransbyWilliamsMin;
      
    const flows = calculateRationalFlows(ws, project.settings.montanaParams, chosenValue);
    
    return {
      ...ws,
      calculatedTc: {
        kirpichMin: tcComp.kirpichMin,
        passiniMin: tcComp.passiniMin,
        giandottiMin: tcComp.giandottiMin,
        bransbyWilliamsMin: tcComp.bransbyWilliamsMin,
        chosenMethod,
        chosenValueMin: chosenValue
      },
      calculatedFlows: {
        q10: flows.flowsM3s.q10,
        q25: flows.flowsM3s.q25,
        q50: flows.flowsM3s.q50,
        q100: flows.flowsM3s.q100,
        rainfallIntensityMmH: flows.intensityMmH.t25
      }
    };
  });

  // 2. Recalcul hydraulique sur chaque ouvrage
  const updatedStructures = project.structures.map(struct => {
    // Si l'ouvrage est rattaché à un BV, synchroniser le débit de dimensionnement avec le Q25/Q50
    const matchedWs = updatedWatersheds.find(w => w.id === struct.watershedId);
    let designFlow = struct.designFlowM3s;
    let checkFlow = struct.checkFlowM3s;
    if (matchedWs && matchedWs.calculatedFlows) {
      if (project.settings.returnPeriodDesignYears === 25) {
        designFlow = matchedWs.calculatedFlows.q25;
      } else if (project.settings.returnPeriodDesignYears === 50) {
        designFlow = matchedWs.calculatedFlows.q50;
      } else {
        designFlow = matchedWs.calculatedFlows.q10;
      }
      checkFlow = matchedWs.calculatedFlows.q100;
    }

    const structWithFlow: typeof struct = {
      ...struct,
      designFlowM3s: designFlow,
      checkFlowM3s: checkFlow
    };

    const calcResults = calculateHydraulicBehavior(structWithFlow, project.settings);
    return {
      ...structWithFlow,
      results: calcResults
    };
  });

  return {
    ...project,
    updatedAt: new Date().toISOString(),
    watersheds: updatedWatersheds,
    structures: updatedStructures
  };
}

/**
 * Récupère le projet actif stocké ou initialise le projet réel par défaut
 */
export function getStoredProject(): Project {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Project;
      return recalculateEntireProject(parsed);
    }
  } catch (err) {
    console.error('Erreur lecture stockage local:', err);
  }
  
  const initialized = recalculateEntireProject(DEFAULT_REAL_PROJECT);
  saveProject(initialized);
  return initialized;
}

/**
 * Sauvegarde le projet dans le stockage local persistant
 */
export function saveProject(project: Project): void {
  try {
    const recalculated = recalculateEntireProject(project);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(recalculated));
  } catch (err) {
    console.error('Erreur écriture stockage local:', err);
  }
}

/**
 * Export du projet au format JSON téléchargeable
 */
export function exportProjectToJson(project: Project): void {
  const jsonStr = JSON.stringify(project, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `OASIS_${project.code}_${new Date().toISOString().slice(0, 10)}.oasis.json`;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Export des ouvrages et bassins au format GeoJSON standard pour SIG (QGIS, ArcGIS)
 */
export function exportProjectToGeoJson(project: Project): void {
  const features: any[] = [];
  
  // Polygones Bassins Versants
  project.watersheds.forEach(ws => {
    if (ws.coordinates && ws.coordinates.length > 2) {
      const coords = ws.coordinates.map(pt => [pt.lng, pt.lat]);
      // Fermer le polygone si pas fermé
      if (coords[0][0] !== coords[coords.length - 1][0] || coords[0][1] !== coords[coords.length - 1][1]) {
        coords.push([coords[0][0], coords[0][1]]);
      }
      features.push({
        type: 'Feature',
        properties: {
          id: ws.id,
          code: ws.code,
          nom: ws.name,
          surface_km2: ws.areaKm2,
          longueur_km: ws.lengthKm,
          pente_pct: ws.slopePercent,
          coeff_c: ws.runoffCoefficient,
          tc_min: ws.calculatedTc?.chosenValueMin,
          q10_m3s: ws.calculatedFlows?.q10,
          q25_m3s: ws.calculatedFlows?.q25,
          q100_m3s: ws.calculatedFlows?.q100
        },
        geometry: {
          type: 'Polygon',
          coordinates: [coords]
        }
      });
    }
  });

  // Points Ouvrages Hydrauliques
  project.structures.forEach(st => {
    features.push({
      type: 'Feature',
      properties: {
        id: st.id,
        code: st.code,
        pk_m: st.pkMeters,
        nom: st.name,
        type: st.type,
        materiau: st.material,
        q_projet_m3s: st.designFlowM3s,
        vitesse_ms: st.results?.flowVelocityMs,
        hauteur_eau_m: st.results?.normalDepthM,
        statut_conformite: st.results?.status,
        anomalies: st.results?.auditIssues?.join(' ; ')
      },
      geometry: {
        type: 'Point',
        coordinates: [st.position.lng, st.position.lat]
      }
    });
  });

  const geoJson = {
    type: 'FeatureCollection',
    name: `OASIS_HYDRO_SUITE_${project.code}`,
    crs: {
      type: 'name',
      properties: { name: 'urn:ogc:def:crs:OGC:1.3:CRS84' }
    },
    features
  };

  const blob = new Blob([JSON.stringify(geoJson, null, 2)], { type: 'application/geo+json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `OASIS_${project.code}_SIG_Couches.geojson`;
  a.click();
  URL.revokeObjectURL(url);
}
