/**
 * OASIS HYDRO SUITE — Service Métier (Service Layer)
 * Orchestration des calculs physiques, contrôles qualité et persistance en base
 */

import { 
  getAllProjects, 
  getProjectById, 
  saveOrUpdateFullProject, 
  seedInitialProjectIfEmpty 
} from '../db/repositories/projectRepository.ts';
import { Project, Watershed, HydraulicStructure, ProjectSettings } from '../types/oasis.ts';
import { recalculateEntireProject } from './storageService.ts';

export class ProjectService {
  /**
   * Récupère le projet actif (ou l'initialise si la base est neuve)
   */
  static async getActiveProject(projectId?: string): Promise<Project> {
    if (projectId) {
      const found = await getProjectById(projectId);
      if (found) return found;
    }
    return await seedInitialProjectIfEmpty();
  }

  /**
   * Sauvegarde complète d'un projet avec recalcul systématique
   */
  static async saveProject(project: Project): Promise<Project> {
    const fullyRecalculated = recalculateEntireProject(project);
    return await saveOrUpdateFullProject(fullyRecalculated);
  }

  /**
   * Met à jour les réglages normatifs d'un projet et recalcule
   */
  static async updateProjectSettings(projectId: string, settings: ProjectSettings): Promise<Project> {
    const proj = await this.getActiveProject(projectId);
    const updated: Project = {
      ...proj,
      settings
    };
    return await this.saveProject(updated);
  }

  /**
   * Ajoute ou met à jour un bassin versant
   */
  static async upsertWatershed(projectId: string, watershed: Watershed): Promise<Project> {
    const proj = await this.getActiveProject(projectId);
    const exists = proj.watersheds.some(w => w.id === watershed.id);
    const updatedWatersheds = exists
      ? proj.watersheds.map(w => w.id === watershed.id ? watershed : w)
      : [...proj.watersheds, watershed];

    return await this.saveProject({
      ...proj,
      watersheds: updatedWatersheds
    });
  }

  /**
   * Met à jour la géométrie ou les paramètres d'un ouvrage hydraulique
   */
  static async upsertStructure(projectId: string, structure: HydraulicStructure): Promise<Project> {
    const proj = await this.getActiveProject(projectId);
    const exists = proj.structures.some(s => s.id === structure.id);
    const updatedStructures = exists
      ? proj.structures.map(s => s.id === structure.id ? structure : s)
      : [...proj.structures, structure];

    return await this.saveProject({
      ...proj,
      structures: updatedStructures
    });
  }
}
