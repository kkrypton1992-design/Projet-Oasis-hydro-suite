/**
 * OASIS HYDRO SUITE — Application Principale (Web & Desktop)
 * Plateforme professionnelle d'ingénierie hydrologique, hydraulique et dimensionnement d'ouvrages
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab, HydraulicStructure, Project, ProjectSettings } from './types/oasis';
import { getStoredProject } from './services/storageService';
import { ApiClient } from './services/apiClient';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { GisMap } from './components/gis/GisMap';
import { HydrologyView } from './components/hydrology/HydrologyView';
import { HydraulicsView } from './components/hydraulics/HydraulicsView';
import { DimensioningView } from './components/dimensioning/DimensioningView';
import { QualityView } from './components/quality/QualityView';
import { ReportViewer } from './components/reporting/ReportViewer';
import { HydroAIAssistant } from './components/ai/HydroAIAssistant';
import { DesktopPackagingView } from './components/desktop/DesktopPackagingView';

export default function App() {
  const [project, setProject] = useState<Project>(() => getStoredProject());
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Chargement initial depuis PostgreSQL via l'API REST
  useEffect(() => {
    let isMounted = true;
    ApiClient.getActiveProject().then((loaded) => {
      if (isMounted && loaded) {
        setProject(loaded);
      }
    }).catch((err) => {
      console.warn('Initialisation projet via API:', err);
    });
    return () => { isMounted = false; };
  }, []);

  // Synchronisation avec l'API Electron native si exécuté en mode Desktop PC
  useEffect(() => {
    const desktopApi = (window as any).oasisDesktop;
    if (desktopApi) {
      const unsubMenu = desktopApi.onMenuAction((action: string) => {
        if (action === 'save-project') handleSave();
        if (action === 'print-report') setActiveTab('reporting');
      });

      const unsubTab = desktopApi.onSwitchTab((tab: ActiveTab) => {
        setActiveTab(tab);
      });

      return () => {
        unsubMenu?.();
        unsubTab?.();
      };
    }
  }, [project]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  // Sauvegarde manuelle dans PostgreSQL
  const handleSave = async () => {
    setIsSaving(true);
    try {
      const saved = await ApiClient.saveProject(project);
      setProject(saved);
      showNotification('Projet enregistré avec succès dans PostgreSQL & cache local');
    } catch (err) {
      console.error('Erreur sauvegarde:', err);
      showNotification('Sauvegarde effectuée dans le stockage local');
    } finally {
      setIsSaving(false);
    }
  };

  // Mise à jour globale du projet
  const handleUpdateProject = async (updated: Project) => {
    setProject(updated);
    try {
      const saved = await ApiClient.saveProject(updated);
      setProject(saved);
    } catch (err) {
      console.warn('Sauvegarde différée:', err);
    }
  };

  // Mise à jour d'un ouvrage hydraulique
  const handleUpdateStructure = async (updatedStructure: HydraulicStructure) => {
    const updatedStructures = project.structures.map(s =>
      s.id === updatedStructure.id ? updatedStructure : s
    );
    const updatedProj: Project = {
      ...project,
      structures: updatedStructures
    };
    setProject(updatedProj);
    try {
      const saved = await ApiClient.updateStructure(project.id, updatedStructure);
      setProject(saved);
    } catch (err) {
      console.warn('Mise à jour ouvrage locale:', err);
    }
  };

  // Application d'un dimensionnement normatif optimal
  const handleApplyDimensioning = async (structureId: string, updates: Partial<HydraulicStructure>) => {
    const target = project.structures.find(s => s.id === structureId);
    if (!target) return;

    const modified: HydraulicStructure = {
      ...target,
      ...updates
    };

    await handleUpdateStructure(modified);
    showNotification(`Dimensionnement optimal appliqué et persisté dans PostgreSQL !`);
  };

  // Mise à jour des réglages normatifs globaux
  const handleUpdateSettings = async (settings: ProjectSettings) => {
    const updatedProj: Project = {
      ...project,
      settings
    };
    setProject(updatedProj);
    try {
      const saved = await ApiClient.updateSettings(project.id, settings);
      setProject(saved);
    } catch (err) {
      console.warn('Mise à jour réglages locale:', err);
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#F5F7FA] font-['Inter',sans-serif] text-slate-800">
      {/* En-tête supérieur */}
      <Header
        project={project}
        onSave={handleSave}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isSaving={isSaving}
      />

      {/* Corps principal : Barre latérale + Contenu dynamique */}
      <div className="flex flex-1 overflow-hidden relative">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          project={project}
        />

        {/* Zone de travail principale */}
        <main className="flex-1 overflow-y-auto p-6 relative">
          {/* Notification toast */}
          {notification && (
            <div className="fixed top-20 right-8 z-50 bg-[#0E4A7B] text-white px-4 py-2.5 rounded-xl shadow-xl text-xs font-semibold flex items-center gap-2 border border-[#00A3E0] animate-bounce">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span>{notification}</span>
            </div>
          )}

          {activeTab === 'dashboard' && (
            <DashboardView
              project={project}
              setActiveTab={setActiveTab}
            />
          )}

          {activeTab === 'gis' && (
            <GisMap
              project={project}
              onSelectStructure={(st) => {
                setActiveTab('hydraulics');
              }}
              onSelectWatershed={(ws) => {
                setActiveTab('hydrology');
              }}
            />
          )}

          {activeTab === 'hydrology' && (
            <HydrologyView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeTab === 'hydraulics' && (
            <HydraulicsView
              project={project}
              onUpdateStructure={handleUpdateStructure}
            />
          )}

          {activeTab === 'dimensioning' && (
            <DimensioningView
              project={project}
              onApplyDimensioning={handleApplyDimensioning}
            />
          )}

          {activeTab === 'quality' && (
            <QualityView
              project={project}
              onUpdateSettings={handleUpdateSettings}
              onSelectStructureForFix={(structId) => {
                setActiveTab('dimensioning');
              }}
            />
          )}

          {activeTab === 'reporting' && (
            <ReportViewer project={project} />
          )}

          {activeTab === 'ai' && (
            <HydroAIAssistant project={project} />
          )}

          {activeTab === 'desktop' && (
            <DesktopPackagingView project={project} />
          )}
        </main>
      </div>
    </div>
  );
}
