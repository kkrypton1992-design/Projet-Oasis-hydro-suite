/**
 * OASIS HYDRO SUITE — Repository Stations & Séries Pluviométriques
 */

import { eq } from 'drizzle-orm';
import { db } from '../index.ts';
import { stations, hydroSeries } from '../schema.ts';

export async function getAllStations() {
  try {
    return await db.select().from(stations);
  } catch (error) {
    console.error('Erreur SQL getAllStations:', error);
    throw new Error('Échec de récupération des stations.', { cause: error });
  }
}

export async function getSeriesByStationId(stationId: string) {
  try {
    return await db.select().from(hydroSeries).where(eq(hydroSeries.stationId, stationId));
  } catch (error) {
    console.error(`Erreur SQL getSeriesByStationId(${stationId}):`, error);
    throw new Error('Échec de récupération des séries hydro-pluviométriques.', { cause: error });
  }
}
