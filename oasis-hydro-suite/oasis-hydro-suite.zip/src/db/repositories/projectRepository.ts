/**
 * OASIS HYDRO SUITE — Repository PostgreSQL : Projets, Bassins & Ouvrages
 * Requêtes typées via Drizzle ORM avec gestion d'erreurs sécurisée
 */

import { eq } from 'drizzle-orm';
import { db } from '../index.ts';
import { 
  projects, 
  watersheds, 
  hydraulicStructures, 
  studies, 
  scenarios, 
  workflow,
  reports
} from '../schema.ts';
import { Project, Watershed, HydraulicStructure } from '../../types/oasis.ts';
import { DEFAULT_REAL_PROJECT, recalculateEntireProject } from '../../services/storageService.ts';

/**
 * Récupère tous les projets enregistrés en base
 */
export async function getAllProjects(): Promise<Array<{ id: string; code: string; title: string; client: string; updatedAt: Date }>> {
  try {
    return await db.select({
      id: projects.id,
      code: projects.code,
      title: projects.title,
      client: projects.client,
      updatedAt: projects.updatedAt
    }).from(projects);
  } catch (error) {
    console.error('Erreur SQL getAllProjects:', error);
    throw new Error('Impossible de récupérer la liste des projets.', { cause: error });
  }
}

/**
 * Récupère un projet complet avec ses bassins versants et ouvrages hydrauliques
 */
export async function getProjectById(projectId: string): Promise<Project | null> {
  try {
    const projRows = await db.select().from(projects).where(eq(projects.id, projectId));
    if (projRows.length === 0) {
      return null;
    }

    const p = projRows[0];
    const wsRows = await db.select().from(watersheds).where(eq(watersheds.projectId, projectId));
    const stRows = await db.select().from(hydraulicStructures).where(eq(hydraulicStructures.projectId, projectId));

    const mappedWatersheds: Watershed[] = wsRows.map(w => ({
      id: w.id,
      code: w.code,
      name: w.name,
      areaKm2: w.areaKm2,
      lengthKm: w.lengthKm,
      deltaH: w.deltaH,
      slopePercent: w.slopePercent,
      runoffCoefficient: w.runoffCoefficient,
      soilType: w.soilType,
      vegetation: w.vegetation,
      color: w.color,
      coordinates: (w.coordinates as any) || [],
      calculatedTc: (w.calculatedTc as any) || undefined,
      calculatedFlows: (w.calculatedFlows as any) || undefined
    }));

    const mappedStructures: HydraulicStructure[] = stRows.map(s => ({
      id: s.id,
      code: s.code,
      pkMeters: s.pkMeters,
      name: s.name,
      type: s.type as any,
      material: s.material as any,
      stricklerK: s.stricklerK,
      diameterM: s.diameterM ?? undefined,
      widthM: s.widthM ?? undefined,
      heightM: s.heightM ?? undefined,
      sideSlopeM: s.sideSlopeM ?? undefined,
      cellsCount: s.cellsCount,
      lengthM: s.lengthM,
      bedSlopeMPerM: s.bedSlopeMPerM,
      watershedId: s.watershedId,
      designFlowM3s: s.designFlowM3s,
      checkFlowM3s: s.checkFlowM3s,
      position: (s.position as any) || { lat: 0, lng: 0 },
      results: (s.results as any) || undefined
    }));

    return {
      id: p.id,
      code: p.code,
      title: p.title,
      client: p.client,
      engineer: p.engineer,
      location: p.location,
      description: p.description,
      status: p.status as any,
      version: p.version,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
      settings: p.settings as any,
      watersheds: mappedWatersheds,
      structures: mappedStructures
    };
  } catch (error) {
    console.error(`Erreur SQL getProjectById(${projectId}):`, error);
    throw new Error(`Échec de récupération du projet ${projectId}.`, { cause: error });
  }
}

/**
 * Sauvegarde ou met à jour un projet complet (avec ses BV et ses Ouvrages) dans PostgreSQL
 */
export async function saveOrUpdateFullProject(project: Project): Promise<Project> {
  try {
    const recalculated = recalculateEntireProject(project);

    // 1. Upsert du projet principal
    await db.insert(projects).values({
      id: recalculated.id,
      code: recalculated.code,
      title: recalculated.title,
      client: recalculated.client,
      engineer: recalculated.engineer,
      location: recalculated.location,
      description: recalculated.description,
      status: recalculated.status,
      version: recalculated.version,
      settings: recalculated.settings,
      updatedAt: new Date()
    }).onConflictDoUpdate({
      target: projects.id,
      set: {
        title: recalculated.title,
        client: recalculated.client,
        engineer: recalculated.engineer,
        location: recalculated.location,
        description: recalculated.description,
        status: recalculated.status,
        version: recalculated.version,
        settings: recalculated.settings,
        updatedAt: new Date()
      }
    });

    // 2. Synchronisation des bassins versants
    for (const ws of recalculated.watersheds) {
      await db.insert(watersheds).values({
        id: ws.id,
        projectId: recalculated.id,
        code: ws.code,
        name: ws.name,
        areaKm2: ws.areaKm2,
        lengthKm: ws.lengthKm,
        deltaH: ws.deltaH,
        slopePercent: ws.slopePercent,
        runoffCoefficient: ws.runoffCoefficient,
        soilType: ws.soilType,
        vegetation: ws.vegetation,
        color: ws.color || '#0284c7',
        coordinates: ws.coordinates,
        calculatedTc: ws.calculatedTc,
        calculatedFlows: ws.calculatedFlows
      }).onConflictDoUpdate({
        target: watersheds.id,
        set: {
          code: ws.code,
          name: ws.name,
          areaKm2: ws.areaKm2,
          lengthKm: ws.lengthKm,
          deltaH: ws.deltaH,
          slopePercent: ws.slopePercent,
          runoffCoefficient: ws.runoffCoefficient,
          soilType: ws.soilType,
          vegetation: ws.vegetation,
          color: ws.color || '#0284c7',
          coordinates: ws.coordinates,
          calculatedTc: ws.calculatedTc,
          calculatedFlows: ws.calculatedFlows
        }
      });
    }

    // 3. Synchronisation des ouvrages hydrauliques
    for (const st of recalculated.structures) {
      await db.insert(hydraulicStructures).values({
        id: st.id,
        projectId: recalculated.id,
        watershedId: st.watershedId,
        code: st.code,
        pkMeters: st.pkMeters,
        name: st.name,
        type: st.type,
        material: st.material,
        stricklerK: st.stricklerK,
        diameterM: st.diameterM,
        widthM: st.widthM,
        heightM: st.heightM,
        sideSlopeM: st.sideSlopeM,
        cellsCount: st.cellsCount || 1,
        lengthM: st.lengthM,
        bedSlopeMPerM: st.bedSlopeMPerM,
        designFlowM3s: st.designFlowM3s,
        checkFlowM3s: st.checkFlowM3s,
        position: st.position,
        results: st.results
      }).onConflictDoUpdate({
        target: hydraulicStructures.id,
        set: {
          watershedId: st.watershedId,
          code: st.code,
          pkMeters: st.pkMeters,
          name: st.name,
          type: st.type,
          material: st.material,
          stricklerK: st.stricklerK,
          diameterM: st.diameterM,
          widthM: st.widthM,
          heightM: st.heightM,
          sideSlopeM: st.sideSlopeM,
          cellsCount: st.cellsCount || 1,
          lengthM: st.lengthM,
          bedSlopeMPerM: st.bedSlopeMPerM,
          designFlowM3s: st.designFlowM3s,
          checkFlowM3s: st.checkFlowM3s,
          position: st.position,
          results: st.results
        }
      });
    }

    return recalculated;
  } catch (error) {
    console.error('Erreur SQL saveOrUpdateFullProject:', error);
    throw new Error('Échec de persistance du projet en base PostgreSQL.', { cause: error });
  }
}

/**
 * Initialise le projet de référence en base PostgreSQL si la table est vide
 */
export async function seedInitialProjectIfEmpty(): Promise<Project> {
  try {
    const existing = await db.select().from(projects).limit(1);
    if (existing.length === 0) {
      console.log('Seeding initial du projet de référence dans PostgreSQL...');
      return await saveOrUpdateFullProject(DEFAULT_REAL_PROJECT);
    }
    const full = await getProjectById(existing[0].id);
    return full || DEFAULT_REAL_PROJECT;
  } catch (error) {
    console.error('Erreur seedInitialProjectIfEmpty:', error);
    return DEFAULT_REAL_PROJECT;
  }
}
