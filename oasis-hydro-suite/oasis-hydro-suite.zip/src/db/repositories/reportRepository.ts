/**
 * OASIS HYDRO SUITE — Repository Rapports & Workflow
 */

import { eq } from 'drizzle-orm';
import { db } from '../index.ts';
import { reports, workflow } from '../schema.ts';

export async function getReportsByProjectId(projectId: string) {
  try {
    return await db.select().from(reports).where(eq(reports.projectId, projectId));
  } catch (error) {
    console.error(`Erreur SQL getReportsByProjectId(${projectId}):`, error);
    throw new Error('Échec de récupération des rapports du projet.', { cause: error });
  }
}

export async function saveReport(reportData: {
  id: string;
  projectId: string;
  code: string;
  title: string;
  type?: string;
  status?: string;
  content: any;
}) {
  try {
    return await db.insert(reports).values({
      id: reportData.id,
      projectId: reportData.projectId,
      code: reportData.code,
      title: reportData.title,
      type: reportData.type || 'HYDRAULIC_CALCULATION_NOTE',
      status: reportData.status || 'DRAFT',
      content: reportData.content
    }).onConflictDoUpdate({
      target: reports.id,
      set: {
        title: reportData.title,
        status: reportData.status || 'DRAFT',
        content: reportData.content
      }
    });
  } catch (error) {
    console.error('Erreur SQL saveReport:', error);
    throw new Error('Échec de sauvegarde du rapport.', { cause: error });
  }
}

export async function getWorkflowByProjectId(projectId: string) {
  try {
    return await db.select().from(workflow).where(eq(workflow.projectId, projectId));
  } catch (error) {
    console.error(`Erreur SQL getWorkflowByProjectId(${projectId}):`, error);
    throw new Error('Échec de récupération du workflow du projet.', { cause: error });
  }
}
