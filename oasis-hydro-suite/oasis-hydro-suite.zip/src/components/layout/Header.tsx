/**
 * OASIS HYDRO SUITE — En-tête Supérieur Professionnel
 */

import React from 'react';
import { 
  Waves, 
  Save, 
  Download, 
  FileText, 
  MapPin, 
  HardDrive, 
  ShieldCheck, 
  Share2,
  Printer
} from 'lucide-react';
import { Project, ActiveTab } from '../../types/oasis';
import { exportProjectToJson, exportProjectToGeoJson } from '../../services/storageService';

interface HeaderProps {
  project: Project;
  onSave: () => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isSaving: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  project,
  onSave,
  activeTab,
  setActiveTab,
  isSaving
}) => {
  return (
    <header className="h-16 bg-[#0E4A7B] text-white flex items-center justify-between px-6 border-b border-[#0A3558] shadow-md z-30 select-none">
      {/* Logo & Identité Produit */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#00A3E0] to-[#38BDF8] flex items-center justify-center shadow-inner">
          <Waves className="w-6 h-6 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-bold text-lg tracking-wide uppercase font-['Montserrat']">
              OASIS HYDRO SUITE
            </h1>
            <span className="bg-[#00A3E0]/30 text-[#38BDF8] text-[10px] font-semibold px-2 py-0.5 rounded-full border border-[#00A3E0]/40">
              v{project.version} · PRO
            </span>
          </div>
          <p className="text-xs text-blue-200 truncate max-w-md hidden sm:block">
            {project.title}
          </p>
        </div>
      </div>

      {/* Métadonnées du Projet & Statut */}
      <div className="hidden lg:flex items-center gap-6 text-xs text-blue-100 bg-[#0B3B63] px-4 py-1.5 rounded-lg border border-[#14568D]">
        <div className="flex items-center gap-1.5">
          <span className="font-semibold text-white">Code :</span>
          <span className="font-mono bg-[#0E4A7B] px-1.5 py-0.5 rounded text-cyan-300">{project.code}</span>
        </div>
        <div className="w-px h-4 bg-blue-700/60" />
        <div className="flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-cyan-400" />
          <span className="truncate max-w-[160px]">{project.location}</span>
        </div>
        <div className="w-px h-4 bg-blue-700/60" />
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-emerald-300 font-medium">Q{project.settings.returnPeriodDesignYears} Ans</span>
        </div>
      </div>

      {/* Actions & Sauvegarde Réelle */}
      <div className="flex items-center gap-2">
        {/* Export SIG GeoJSON */}
        <button
          onClick={() => exportProjectToGeoJson(project)}
          title="Exporter toutes les couches géoréférencées (Bassins et Ouvrages) en GeoJSON standard pour QGIS/ArcGIS"
          className="flex items-center gap-1.5 bg-[#0B3B63] hover:bg-[#14568D] text-blue-100 hover:text-white px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border border-[#17629F]"
        >
          <Share2 className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden md:inline">Export SIG</span>
        </button>

        {/* Export JSON Projet */}
        <button
          onClick={() => exportProjectToJson(project)}
          title="Télécharger l'intégralité du projet en fichier (.oasis.json)"
          className="flex items-center gap-1.5 bg-[#0B3B63] hover:bg-[#14568D] text-blue-100 hover:text-white px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border border-[#17629F]"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden md:inline">Sauvegarder JSON</span>
        </button>

        {/* Télécharger l'archive ZIP complète du projet */}
        <a
          href="/oasis-hydro-suite.zip"
          download="oasis-hydro-suite.zip"
          title="Télécharger l'archive ZIP complète contenant tout le code source, electron et build"
          className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-sm"
        >
          <Download className="w-3.5 h-3.5 text-white" />
          <span className="hidden sm:inline">Télécharger ZIP</span>
        </a>

        {/* Impression Rapport */}
        <button
          onClick={() => setActiveTab('reporting')}
          title="Afficher et imprimer la Note de Calculs officielle"
          className="flex items-center gap-1.5 bg-[#0B3B63] hover:bg-[#14568D] text-blue-100 hover:text-white px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border border-[#17629F]"
        >
          <Printer className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden md:inline">Note de Calcul</span>
        </button>

        {/* Sauvegarder dans la base locale */}
        <button
          onClick={onSave}
          disabled={isSaving}
          className="flex items-center gap-1.5 bg-[#00A3E0] hover:bg-[#0091C8] active:scale-95 text-white px-4 py-1.5 rounded-lg text-xs font-semibold shadow transition-all"
        >
          <Save className={`w-3.5 h-3.5 ${isSaving ? 'animate-spin' : ''}`} />
          <span>{isSaving ? 'Enregistrement...' : 'Enregistrer'}</span>
        </button>
      </div>
    </header>
  );
};
