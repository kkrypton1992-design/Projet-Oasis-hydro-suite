/**
 * OASIS HYDRO SUITE — Solveur Hydraulique Manning-Strickler Certifié
 * Résolution numérique exacte des équations d'écoulement à surface libre
 * et rendu SVG géométrique de la section transversale en eau.
 */

import React, { useState } from 'react';
import { 
  Activity, 
  Sliders, 
  Layers, 
  ShieldCheck, 
  ShieldAlert, 
  RefreshCw, 
  ArrowRight,
  Maximize2
} from 'lucide-react';
import { HydraulicStructure, Project, StructureType, MaterialType } from '../../types/oasis';
import { calculateHydraulicBehavior } from '../../core/hydraulicEngine';

interface HydraulicsViewProps {
  project: Project;
  onUpdateStructure: (updated: HydraulicStructure) => void;
}

export const HydraulicsView: React.FC<HydraulicsViewProps> = ({
  project,
  onUpdateStructure
}) => {
  const [selectedStructureId, setSelectedStructureId] = useState<string>(project.structures[0]?.id || '');

  const activeStructure = project.structures.find(s => s.id === selectedStructureId) || project.structures[0];

  // Calcul hydraulique en direct
  const results = activeStructure
    ? calculateHydraulicBehavior(activeStructure, project.settings)
    : null;

  // Modification d'un paramètre
  const handleParamChange = (field: keyof HydraulicStructure, value: any) => {
    if (!activeStructure) return;
    const updated: HydraulicStructure = {
      ...activeStructure,
      [field]: value
    };
    // Recalcul immédiat
    const newResults = calculateHydraulicBehavior(updated, project.settings);
    onUpdateStructure({
      ...updated,
      results: newResults
    });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* En-tête */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-blue-100 text-[#0E4A7B] text-xs font-bold px-2.5 py-0.5 rounded-full font-mono">
              Module Métier M-04
            </span>
            <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">
              Écoulement Uniforme & Régimes de Froude
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 font-['Montserrat']">
            Solveur Hydraulique Manning-Strickler (Ligne d'Eau)
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Résolution par dichotomie de l'équation implicite : Q = K · S · Rh^(2/3) · √S₀. Calcul des hauteurs normale yn, critique yc et vitesses d'écoulement.
          </p>
        </div>

        {/* Sélecteur d'ouvrage */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-600">Ouvrage :</label>
          <select
            value={selectedStructureId}
            onChange={(e) => setSelectedStructureId(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
          >
            {project.structures.map(st => (
              <option key={st.id} value={st.id}>
                {st.code} — PK {Math.floor(st.pkMeters / 1000)}+{String(st.pkMeters % 1000).padStart(3, '0')} ({st.name})
              </option>
            ))}
          </select>
        </div>
      </div>

      {activeStructure && results && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Colonne Gauche : Paramètres Géométriques & Hydrauliques (5 colonnes) */}
          <div className="lg:col-span-5 bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm font-['Montserrat'] flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#00A3E0]" />
                <span>Paramètres de Calcul</span>
              </h3>
              <span className="text-xs font-mono font-bold text-[#0E4A7B]">
                {activeStructure.code}
              </span>
            </div>

            <div className="space-y-3.5 text-xs">
              {/* Type de profil */}
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Type d'Ouvrage</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handleParamChange('type', 'CIRCULAR_PIPE')}
                    className={`py-2 px-2 rounded-xl font-bold border transition-all ${
                      activeStructure.type === 'CIRCULAR_PIPE'
                        ? 'bg-[#0E4A7B] text-white border-[#0E4A7B] shadow-sm'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Buse Circulaire
                  </button>
                  <button
                    onClick={() => handleParamChange('type', 'BOX_CULVERT')}
                    className={`py-2 px-2 rounded-xl font-bold border transition-all ${
                      activeStructure.type === 'BOX_CULVERT'
                        ? 'bg-[#0E4A7B] text-white border-[#0E4A7B] shadow-sm'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Dalot Cadre
                  </button>
                  <button
                    onClick={() => handleParamChange('type', 'DITCH')}
                    className={`py-2 px-2 rounded-xl font-bold border transition-all ${
                      activeStructure.type === 'DITCH'
                        ? 'bg-[#0E4A7B] text-white border-[#0E4A7B] shadow-sm'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Fossé Trapézoïdal
                  </button>
                </div>
              </div>

              {/* Dimensions spécifiques selon le type */}
              {activeStructure.type === 'CIRCULAR_PIPE' && (
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Diamètre Intérieur D (mètres)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      step="0.10"
                      min="0.30"
                      max="3.00"
                      value={activeStructure.diameterM || 1.20}
                      onChange={(e) => handleParamChange('diameterM', parseFloat(e.target.value) || 1.0)}
                      className="w-24 px-3 py-1.5 border rounded-lg font-mono font-bold text-slate-800"
                    />
                    <span className="text-slate-500 font-mono">
                      Ø {Math.round((activeStructure.diameterM || 1.2) * 1000)} mm
                    </span>
                  </div>
                </div>
              )}

              {activeStructure.type === 'BOX_CULVERT' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Largeur intérieure B (m)
                    </label>
                    <input
                      type="number"
                      step="0.25"
                      min="0.50"
                      max="6.00"
                      value={activeStructure.widthM || 2.50}
                      onChange={(e) => handleParamChange('widthM', parseFloat(e.target.value) || 1.0)}
                      className="w-full px-3 py-1.5 border rounded-lg font-mono font-bold text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Hauteur intérieure H (m)
                    </label>
                    <input
                      type="number"
                      step="0.25"
                      min="0.50"
                      max="4.00"
                      value={activeStructure.heightM || 1.50}
                      onChange={(e) => handleParamChange('heightM', parseFloat(e.target.value) || 1.0)}
                      className="w-full px-3 py-1.5 border rounded-lg font-mono font-bold text-slate-800"
                    />
                  </div>
                </div>
              )}

              {activeStructure.type === 'DITCH' && (
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Largeur fond b (m)</label>
                    <input
                      type="number"
                      step="0.10"
                      min="0"
                      value={activeStructure.widthM || 0.80}
                      onChange={(e) => handleParamChange('widthM', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 border rounded-lg font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Fruit berge m</label>
                    <input
                      type="number"
                      step="0.25"
                      min="0"
                      value={activeStructure.sideSlopeM || 1.5}
                      onChange={(e) => handleParamChange('sideSlopeM', parseFloat(e.target.value) || 1.5)}
                      className="w-full px-2 py-1.5 border rounded-lg font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Profondeur H (m)</label>
                    <input
                      type="number"
                      step="0.10"
                      min="0.3"
                      value={activeStructure.heightM || 1.20}
                      onChange={(e) => handleParamChange('heightM', parseFloat(e.target.value) || 1.0)}
                      className="w-full px-2 py-1.5 border rounded-lg font-mono font-bold"
                    />
                  </div>
                </div>
              )}

              {/* Nombre de pertuis (pour dalots ou buses multiples) */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Nombre de Pertuis N</label>
                  <select
                    value={activeStructure.cellsCount || 1}
                    onChange={(e) => handleParamChange('cellsCount', parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-1.5 border rounded-lg font-mono font-bold"
                  >
                    <option value={1}>1 pertuis (Simple)</option>
                    <option value={2}>2 pertuis (Double)</option>
                    <option value={3}>3 pertuis (Triple)</option>
                    <option value={4}>4 pertuis (Quadruple)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Matériau de paroi</label>
                  <select
                    value={activeStructure.material}
                    onChange={(e) => {
                      const mat = e.target.value as MaterialType;
                      let k = 70;
                      if (mat === 'HDPE') k = 80;
                      if (mat === 'CORRUGATED_STEEL') k = 45;
                      if (mat === 'EARTH_GRASSED') k = 35;
                      handleParamChange('material', mat);
                      handleParamChange('stricklerK', k);
                    }}
                    className="w-full px-3 py-1.5 border rounded-lg font-semibold"
                  >
                    <option value="CONCRETE">Béton armé (K=70)</option>
                    <option value="HDPE">PEHD lisse (K=80)</option>
                    <option value="CORRUGATED_STEEL">Métal ondulé (K=45)</option>
                    <option value="EARTH_GRASSED">Terre enherbée (K=35)</option>
                  </select>
                </div>
              </div>

              {/* Paramètres d'écoulement Q, Pente S0, Strickler K */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700">Débit de projet Q :</span>
                  <div className="flex items-center gap-1 font-mono">
                    <input
                      type="number"
                      step="0.10"
                      min="0.05"
                      value={activeStructure.designFlowM3s}
                      onChange={(e) => handleParamChange('designFlowM3s', parseFloat(e.target.value) || 0.1)}
                      className="w-20 px-2 py-1 border rounded text-right font-bold text-[#0E4A7B]"
                    />
                    <span className="text-slate-500 text-xs">m³/s</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700">Pente du radier S₀ :</span>
                  <div className="flex items-center gap-1 font-mono">
                    <input
                      type="number"
                      step="0.001"
                      min="0.0001"
                      max="0.15"
                      value={activeStructure.bedSlopeMPerM}
                      onChange={(e) => handleParamChange('bedSlopeMPerM', parseFloat(e.target.value) || 0.005)}
                      className="w-20 px-2 py-1 border rounded text-right font-bold text-slate-800"
                    />
                    <span className="text-slate-500 text-xs">m/m ({(activeStructure.bedSlopeMPerM * 100).toFixed(2)}%)</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700">Rugosité Strickler K :</span>
                  <div className="flex items-center gap-1 font-mono">
                    <input
                      type="number"
                      step="5"
                      min="15"
                      max="100"
                      value={activeStructure.stricklerK}
                      onChange={(e) => handleParamChange('stricklerK', parseInt(e.target.value) || 70)}
                      className="w-20 px-2 py-1 border rounded text-right font-bold text-slate-800"
                    />
                    <span className="text-slate-500 text-xs">m^(1/3)/s</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Colonne Droite : Représentation Géométrique SVG & Résultats (7 colonnes) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Visualisation graphique SVG de la section transversale en eau */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-bold text-slate-900 font-['Montserrat']">
                  Coupe Transversale Géométrique en Eau
                </h3>
                <span className="text-xs font-mono font-bold text-[#00A3E0]">
                  yn = {results.normalDepthM.toFixed(3)} m · yc = {results.criticalDepthM.toFixed(3)} m
                </span>
              </div>

              {/* Rendu SVG dynamique */}
              <div className="bg-slate-900 rounded-xl p-4 flex items-center justify-center h-64 border border-slate-800 relative overflow-hidden">
                <svg className="w-full h-full max-w-md" viewBox="0 0 300 200">
                  {/* Fond noir technique / carroyage */}
                  <defs>
                    <linearGradient id="waterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#38BDF8" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#0284C7" stopOpacity={0.9} />
                    </linearGradient>
                  </defs>

                  {/* Section Dalot Rectangulaire */}
                  {activeStructure.type === 'BOX_CULVERT' && (
                    <g transform="translate(50, 20)">
                      {/* Contour extérieur dalot (béton) */}
                      <rect x="0" y="0" width="200" height="150" fill="#334155" stroke="#94A3B8" strokeWidth="4" />
                      <rect x="15" y="15" width="170" height="120" fill="#0F172A" stroke="#CBD5E1" strokeWidth="2" />
                      
                      {/* Eau : hauteur normale yn */}
                      {(() => {
                        const H = activeStructure.heightM || 1.5;
                        const waterRatio = Math.min(1.0, results.normalDepthM / H);
                        const waterH = 120 * waterRatio;
                        const waterY = 135 - waterH;

                        const critRatio = Math.min(1.0, results.criticalDepthM / H);
                        const critY = 135 - (120 * critRatio);

                        return (
                          <>
                            <rect x="15" y={waterY} width="170" height={waterH} fill="url(#waterGrad)" />
                            {/* Ligne de surface libre d'eau */}
                            <line x1="15" y1={waterY} x2="185" y2={waterY} stroke="#E0F2FE" strokeWidth="2" />
                            {/* Ligne critique yc en pointillés */}
                            <line x1="15" y1={critY} x2="185" y2={critY} stroke="#F59E0B" strokeWidth="1.5" strokeDasharray="4,3" />
                            {/* Étiquettes */}
                            <text x="195" y={waterY + 4} fill="#38BDF8" fontSize="10" fontFamily="monospace" fontWeight="bold">yn</text>
                            <text x="195" y={critY + 4} fill="#F59E0B" fontSize="9" fontFamily="monospace">yc</text>
                          </>
                        );
                      })()}
                    </g>
                  )}

                  {/* Section Buse Circulaire */}
                  {activeStructure.type === 'CIRCULAR_PIPE' && (
                    <g transform="translate(150, 100)">
                      {/* Buse extérieure béton */}
                      <circle cx="0" cy="0" r="75" fill="#334155" stroke="#94A3B8" strokeWidth="6" />
                      <circle cx="0" cy="0" r="65" fill="#0F172A" stroke="#CBD5E1" strokeWidth="2" />
                      
                      {/* Eau par masque ou arc */}
                      {(() => {
                        const D = activeStructure.diameterM || 1.2;
                        const ratio = Math.min(1.0, results.normalDepthM / D);
                        const waterY = 65 - 130 * ratio; // de +65 à -65

                        return (
                          <g>
                            <clipPath id="pipeClip">
                              <circle cx="0" cy="0" r="64" />
                            </clipPath>
                            <rect
                              x="-65"
                              y={waterY}
                              width="130"
                              height={65 - waterY}
                              fill="url(#waterGrad)"
                              clipPath="url(#pipeClip)"
                            />
                            {/* Surface d'eau */}
                            <line
                              x1={-Math.sqrt(Math.max(0, 64*64 - waterY*waterY))}
                              y1={waterY}
                              x2={Math.sqrt(Math.max(0, 64*64 - waterY*waterY))}
                              y2={waterY}
                              stroke="#E0F2FE"
                              strokeWidth="2"
                            />
                          </g>
                        );
                      })()}
                    </g>
                  )}

                  {/* Section Fossé Trapézoïdal */}
                  {activeStructure.type === 'DITCH' && (
                    <g transform="translate(50, 30)">
                      <polygon points="0,0 60,130 140,130 200,0" fill="#0F172A" stroke="#94A3B8" strokeWidth="3" />
                      {(() => {
                        const H = activeStructure.heightM || 1.2;
                        const ratio = Math.min(1.0, results.normalDepthM / H);
                        const waterH = 130 * ratio;
                        const waterY = 130 - waterH;
                        const leftX = 60 - (60 * ratio);
                        const rightX = 140 + (60 * ratio);

                        return (
                          <>
                            <polygon
                              points={`${leftX},${waterY} 60,130 140,130 ${rightX},${waterY}`}
                              fill="url(#waterGrad)"
                            />
                            <line x1={leftX} y1={waterY} x2={rightX} y2={waterY} stroke="#E0F2FE" strokeWidth="2" />
                          </>
                        );
                      })()}
                    </g>
                  )}
                </svg>

                {/* Légende interne de la coupe */}
                <div className="absolute bottom-2 left-3 text-[10px] text-slate-400 flex items-center gap-3 font-mono">
                  <span className="flex items-center gap-1 text-cyan-300">
                    <span className="w-2.5 h-0.5 bg-cyan-300 inline-block" /> Ligne d'eau normale (yn)
                  </span>
                  <span className="flex items-center gap-1 text-amber-400">
                    <span className="w-2.5 h-0.5 bg-amber-400 border-dashed inline-block" /> Ligne critique (yc)
                  </span>
                </div>
              </div>
            </div>

            {/* Matrice des Résultats Numériques Certifiés */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 font-['Montserrat']">
                  Résultats Hydrauliques Détaillés
                </h3>
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                  results.status === 'COMPLIANT'
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                    : results.status === 'WARNING'
                    ? 'bg-amber-100 text-amber-800 border-amber-200'
                    : 'bg-red-100 text-red-800 border-red-200'
                }`}>
                  {results.status === 'COMPLIANT' ? '100% Conforme' : results.status === 'WARNING' ? 'Avertissement Normatif' : 'Non Conforme'}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Tirant d'eau yn</span>
                  <span className="text-base font-bold font-mono text-[#0E4A7B] mt-0.5 block">
                    {results.normalDepthM.toFixed(3)} m
                  </span>
                  <span className="text-[10px] text-slate-500">Hauteur normale d'eau</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Hauteur critique yc</span>
                  <span className="text-base font-bold font-mono text-amber-600 mt-0.5 block">
                    {results.criticalDepthM.toFixed(3)} m
                  </span>
                  <span className="text-[10px] text-slate-500">Fr = 1.0 (seuil)</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Vitesse moyenne V</span>
                  <span className={`text-base font-bold font-mono mt-0.5 block ${
                    results.flowVelocityMs > 4.0 ? 'text-red-600' : results.flowVelocityMs < 0.6 ? 'text-amber-600' : 'text-emerald-700'
                  }`}>
                    {results.flowVelocityMs.toFixed(2)} m/s
                  </span>
                  <span className="text-[10px] text-slate-500">Norme : 0.60 à 4.0 m/s</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Régime d'écoulement</span>
                  <span className="text-base font-bold font-mono text-slate-800 mt-0.5 block">
                    Fr = {results.froudeNumber.toFixed(2)}
                  </span>
                  <span className="text-[10px] font-semibold text-[#00A3E0] uppercase">
                    {results.flowRegime === 'FLUVIAL' ? 'Fluvial (Fr < 1)' : 'Torrentiel (Fr > 1)'}
                  </span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Section mouillée Sm</span>
                  <span className="text-base font-bold font-mono text-slate-800 mt-0.5 block">
                    {results.wetAreaM2.toFixed(3)} m²
                  </span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Rayon hydraulique Rh</span>
                  <span className="text-base font-bold font-mono text-slate-800 mt-0.5 block">
                    {results.hydraulicRadiusM.toFixed(3)} m
                  </span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Taux de remplissage</span>
                  <span className="text-base font-bold font-mono text-slate-800 mt-0.5 block">
                    {results.fillingRatioPercent.toFixed(1)} %
                  </span>
                  <span className="text-[10px] text-slate-500">Admissible &le; 80%</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Tirant d'air (Revanche)</span>
                  <span className="text-base font-bold font-mono text-slate-800 mt-0.5 block">
                    {results.freeboardM.toFixed(3)} m
                  </span>
                  <span className="text-[10px] text-slate-500">Sécurité flottants</span>
                </div>
              </div>

              {/* Alertes d'anomalies détectées par l'audit */}
              {results.auditIssues.length > 0 && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1 text-xs">
                  <div className="font-bold text-amber-900 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-amber-600" />
                    <span>Points d'Attention & Recommandations Normatives :</span>
                  </div>
                  <ul className="list-disc list-inside text-amber-800 text-[11px] space-y-0.5 pl-1">
                    {results.auditIssues.map((issue, idx) => (
                      <li key={idx}>{issue}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
