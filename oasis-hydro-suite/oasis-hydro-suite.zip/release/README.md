# Répertoire de Distribution des Versions — OASIS HYDRO SUITE

Ce dossier reçoit les exécutables finaux générés pour la distribution commerciale et les déploiements clients :

- **`OASIS HYDRO SUITE Setup 1.2.0.exe`** : Programme d'installation Windows professionnel (avec installateur NSIS, choix du répertoire, création de raccourcis Bureau et Menu Démarrer).
- **`OASIS HYDRO SUITE 1.2.0.exe`** : Version autonome portable (aucune installation requise, idéale pour clé USB sur chantier).
- **`latest.yml`** : Manifeste de contrôle pour les mises à jour automatiques via GitHub Releases ou serveur d'entreprise.

### Procédure de génération de l'installateur :
1. Sur Windows : double-cliquez sur `build/package-windows.bat` ou lancez `npm run package:win`
2. L'exécutable `.exe` est automatiquement signé et déposé dans ce dossier.
