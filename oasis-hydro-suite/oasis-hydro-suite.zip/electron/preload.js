/**
 * OASIS HYDRO SUITE — Electron Preload Bridge
 * Exposition sécurisée de l'API bureau vers le renderer React
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('oasisDesktop', {
  isDesktop: true,
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  onMenuAction: (callback) => {
    const handler = (event, action) => callback(action);
    ipcRenderer.on('menu-action', handler);
    return () => ipcRenderer.removeListener('menu-action', handler);
  },
  onSwitchTab: (callback) => {
    const handler = (event, tab) => callback(tab);
    ipcRenderer.on('switch-tab', handler);
    return () => ipcRenderer.removeListener('switch-tab', handler);
  },
  onLoadProject: (callback) => {
    const handler = (event, content) => callback(content);
    ipcRenderer.on('load-project-content', handler);
    return () => ipcRenderer.removeListener('load-project-content', handler);
  }
});
