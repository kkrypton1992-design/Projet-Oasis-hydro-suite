/**
 * OASIS HYDRO SUITE — Point d'entrée de l'application Desktop Electron
 * Logiciel d'ingénierie hydrologique & hydraulique pour Windows, Linux & macOS
 */

const { app, BrowserWindow, Menu, dialog, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow = null;

const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    title: 'OASIS HYDRO SUITE — Ingénierie Hydrologique & Hydraulique',
    backgroundColor: '#0E4A7B',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      sandbox: true
    },
    icon: path.join(__dirname, '../build/icon.png')
  });

  // Chargement de l'URL ou du fichier compilé
  if (isDev && process.env.VITE_DEV_SERVER_URL) {
    mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  // Configuration du Menu Professionnel
  const template = [
    {
      label: 'Fichier',
      submenu: [
        {
          label: 'Nouveau Projet',
          accelerator: 'CmdOrCtrl+N',
          click: () => mainWindow.webContents.send('menu-action', 'new-project')
        },
        {
          label: 'Ouvrir un Projet (.oasis.json)...',
          accelerator: 'CmdOrCtrl+O',
          click: async () => {
            const { filePaths } = await dialog.showOpenDialog(mainWindow, {
              title: 'Ouvrir un projet OASIS HYDRO SUITE',
              filters: [{ name: 'Projet OASIS (*.oasis.json)', extensions: ['oasis.json', 'json'] }],
              properties: ['openFile']
            });
            if (filePaths && filePaths[0]) {
              const content = fs.readFileSync(filePaths[0], 'utf-8');
              mainWindow.webContents.send('load-project-content', content);
            }
          }
        },
        {
          label: 'Enregistrer le Projet',
          accelerator: 'CmdOrCtrl+S',
          click: () => mainWindow.webContents.send('menu-action', 'save-project')
        },
        { type: 'separator' },
        {
          label: 'Exporter la Note de Calculs (PDF)...',
          accelerator: 'CmdOrCtrl+P',
          click: () => mainWindow.webContents.send('menu-action', 'print-report')
        },
        {
          label: 'Exporter les Couches SIG (GeoJSON)...',
          click: () => mainWindow.webContents.send('menu-action', 'export-geojson')
        },
        { type: 'separator' },
        {
          label: 'Quitter',
          accelerator: 'CmdOrCtrl+Q',
          click: () => app.quit()
        }
      ]
    },
    {
      label: 'Calculs & Modules',
      submenu: [
        { label: 'Tableau de bord', click: () => mainWindow.webContents.send('switch-tab', 'dashboard') },
        { label: 'Cartographie SIG', click: () => mainWindow.webContents.send('switch-tab', 'gis') },
        { label: 'Moteur Hydrologique (Kirpich, Montana, Débits)', click: () => mainWindow.webContents.send('switch-tab', 'hydrology') },
        { label: 'Moteur Hydraulique (Manning-Strickler)', click: () => mainWindow.webContents.send('switch-tab', 'hydraulics') },
        { label: 'Dimensionnement Automatique', click: () => mainWindow.webContents.send('switch-tab', 'dimensioning') },
        { label: 'Contrôle Qualité & Conformité', click: () => mainWindow.webContents.send('switch-tab', 'quality') },
        { label: 'Générateur de Rapports', click: () => mainWindow.webContents.send('switch-tab', 'reporting') },
        { label: 'Assistant IA Central', click: () => mainWindow.webContents.send('switch-tab', 'ai') }
      ]
    },
    {
      label: 'Affichage',
      submenu: [
        { role: 'reload', label: 'Actualiser' },
        { role: 'forceReload', label: 'Forcer l\'actualisation' },
        { role: 'toggleDevTools', label: 'Outils de développement' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'Taille normale' },
        { role: 'zoomIn', label: 'Zoom avant' },
        { role: 'zoomOut', label: 'Zoom arrière' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Plein écran' }
      ]
    },
    {
      label: 'Aide & Licence',
      submenu: [
        {
          label: 'Documentation Technique Officielle',
          click: () => shell.openExternal('https://github.com/kkrypton1992-design/Projet-Oasis-hydro-suite')
        },
        {
          label: 'Vérifier les mises à jour...',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'Mises à jour OASIS HYDRO SUITE',
              message: 'Vous utilisez la dernière version certifiée (v1.2.0-MVP).',
              detail: 'Canal de distribution officiel configuré.'
            });
          }
        },
        { type: 'separator' },
        {
          label: 'À propos d\'OASIS HYDRO SUITE',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'À propos d\'OASIS HYDRO SUITE',
              message: 'OASIS HYDRO SUITE v1.2.0\nSuite Industrielle d\'Ingénierie Hydrologique & Hydraulique',
              detail: 'Calculs certifiés selon formules de Kirpich, Passini, Giandotti et Manning-Strickler.\nConçu pour les bureaux d\'études et directions des infrastructures.'
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Gestion des IPC pour la communication sécurisée Desktop <-> Frontend
ipcMain.handle('get-app-version', () => app.getVersion());
ipcMain.handle('is-desktop-mode', () => true);

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
