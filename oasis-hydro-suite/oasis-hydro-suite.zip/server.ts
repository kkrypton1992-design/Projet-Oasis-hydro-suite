/**
 * OASIS HYDRO SUITE — Serveur Applicatif Full-Stack Express & PostgreSQL
 * API REST pour la persistance réelle et montage du middleware Vite
 */

import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';
import { ProjectService } from './src/services/projectService.ts';
import { getAllProjects, getProjectById } from './src/db/repositories/projectRepository.ts';
import { getAllStations } from './src/db/repositories/stationRepository.ts';
import { getReportsByProjectId, saveReport, getWorkflowByProjectId } from './src/db/repositories/reportRepository.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '15mb' }));

// ==========================================
// API REST RÉELLE — OASIS HYDRO SUITE
// ==========================================

// Santé du serveur & connectivité
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    database: 'Cloud SQL PostgreSQL / PostGIS',
    version: '1.2.0',
    timestamp: new Date().toISOString()
  });
});

// Récupérer le projet actif (avec initialisation automatique si base vierge)
app.get('/api/projects/active', async (req: Request, res: Response) => {
  try {
    const project = await ProjectService.getActiveProject();
    res.json(project);
  } catch (error: any) {
    console.error('Erreur /api/projects/active:', error);
    res.status(500).json({ error: error.message || 'Échec récupération projet actif' });
  }
});

// Liste de tous les projets
app.get('/api/projects', async (req: Request, res: Response) => {
  try {
    const projectsList = await getAllProjects();
    res.json(projectsList);
  } catch (error: any) {
    console.error('Erreur /api/projects:', error);
    res.status(500).json({ error: error.message || 'Échec récupération liste des projets' });
  }
});

// Récupérer un projet spécifique par son ID
app.get('/api/projects/:id', async (req: Request, res: Response) => {
  try {
    const project = await getProjectById(req.params.id);
    if (!project) {
      return res.status(404).json({ error: 'Projet introuvable' });
    }
    res.json(project);
  } catch (error: any) {
    console.error(`Erreur /api/projects/${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Erreur interne' });
  }
});

// Sauvegarde complète d'un projet
app.put('/api/projects/:id', async (req: Request, res: Response) => {
  try {
    const projectData = req.body;
    const saved = await ProjectService.saveProject({
      ...projectData,
      id: req.params.id
    });
    res.json(saved);
  } catch (error: any) {
    console.error(`Erreur PUT /api/projects/${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Échec sauvegarde projet' });
  }
});

// Mise à jour des paramètres normatifs
app.put('/api/projects/:id/settings', async (req: Request, res: Response) => {
  try {
    const updated = await ProjectService.updateProjectSettings(req.params.id, req.body);
    res.json(updated);
  } catch (error: any) {
    console.error(`Erreur PUT /api/projects/${req.params.id}/settings:`, error);
    res.status(500).json({ error: error.message || 'Échec mise à jour paramètres' });
  }
});

// Mise à jour d'un ouvrage hydraulique
app.put('/api/projects/:id/structures/:stId', async (req: Request, res: Response) => {
  try {
    const updated = await ProjectService.upsertStructure(req.params.id, {
      ...req.body,
      id: req.params.stId
    });
    res.json(updated);
  } catch (error: any) {
    console.error(`Erreur PUT /api/projects/${req.params.id}/structures/${req.params.stId}:`, error);
    res.status(500).json({ error: error.message || 'Échec mise à jour ouvrage' });
  }
});

// Mise à jour d'un bassin versant
app.put('/api/projects/:id/watersheds/:wsId', async (req: Request, res: Response) => {
  try {
    const updated = await ProjectService.upsertWatershed(req.params.id, {
      ...req.body,
      id: req.params.wsId
    });
    res.json(updated);
  } catch (error: any) {
    console.error(`Erreur PUT /api/projects/${req.params.id}/watersheds/${req.params.wsId}:`, error);
    res.status(500).json({ error: error.message || 'Échec mise à jour bassin versant' });
  }
});

// Rapports techniques
app.get('/api/projects/:id/reports', async (req: Request, res: Response) => {
  try {
    const projectReports = await getReportsByProjectId(req.params.id);
    res.json(projectReports);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Erreur récupération rapports' });
  }
});

app.post('/api/projects/:id/reports', async (req: Request, res: Response) => {
  try {
    const saved = await saveReport({
      ...req.body,
      projectId: req.params.id
    });
    res.json(saved);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Erreur sauvegarde rapport' });
  }
});

// Workflow et audit trail
app.get('/api/projects/:id/workflow', async (req: Request, res: Response) => {
  try {
    const wf = await getWorkflowByProjectId(req.params.id);
    res.json(wf);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Erreur récupération workflow' });
  }
});

// Stations pluviométriques & hydrométriques
app.get('/api/stations', async (req: Request, res: Response) => {
  try {
    const stationList = await getAllStations();
    res.json(stationList);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Erreur récupération stations' });
  }
});

// ==========================================
// INTÉGRATION FRONTEND VITE
// ==========================================
async function startServer() {
  if (!isProd) {
    // Mode Développement : Montage de Vite en middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Mode Production : Distribution des fichiers statiques compilés
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[OASIS HYDRO SUITE] Serveur démarré avec succès sur http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[OASIS HYDRO SUITE] Échec critique du serveur:', err);
});
